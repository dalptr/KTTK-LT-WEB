<?php
session_start();
if(!isset($_SESSION['username'])){
    header('location:signin.php');
}
$conn = new PDO('mysql:host=localhost;dbname=ontap','student','123456');
$sql = "SELECT NhanVien.ID AS idnv,hoten FROM NhanVien";
$sql2 = "SELECT HangHoa.ID AS idhh,ten FROM HangHoa";

$stmt = $conn->prepare($sql);
$query = $stmt->execute();

$stmt1 = $conn->prepare($sql2);
$query1 = $stmt1->execute();

$result = array();
$result1 = array();

while($row=$stmt->fetch(PDO::FETCH_ASSOC)){
    $result[] = $row;
}

while($row1=$stmt1->fetch(PDO::FETCH_ASSOC)){
    $result1[] = $row1;
}

if(!empty($_POST['submit'])){
    if(isset($_POST['idvandon'])&&isset($_POST['idchitietvandon'])&&isset($_POST['nhanvien'])&&isset($_POST['nguoinhan'])&&isset($_POST['hanghoa'])&&isset($_POST['soluong'])){
        $idvd = $_POST['idvandon'];
        $idctvd = $_POST['idchitietvandon'];
        $nhanvien = $_POST['nhanvien'];
        $nguoinhan = $_POST['nguoinhan'];
        $hanghoa = $_POST['hanghoa'];
        $soluong = $_POST['soluong'];
        $sql = "INSERT INTO VanDon(ID,nhanvien_ID,nguoinhan) VALUES('$idvd','$nhanvien','$nguoinhan');INSERT INTO ChiTietVanDon(ID,vandon,hanghoa_ID,soluong) VALUES('$idctvd','$idvd','$hanghoa','$soluong')";
        var_dump($sql);
        $stmt = $conn->prepare($sql);
        $query = $stmt->execute();
        if($query){
            header('location:list.php');
        }
        else{
            echo "Thêm dữ liệu thất bại";
        }
    }
}

?>