<?php
session_start();
$conn = new PDO('mysql:host=localhost;dbname=ontap','student','123456');
if(!empty($_POST['submit'])) {
    if (isset($_POST['username']) && isset($_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $sql = "SELECT * FROM user WHERE username = '$username' AND matkhau = '$password'";
        $stmt = $conn->prepare($sql);
        $query = $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            echo "Tài khoản hoặc mật khẩu không đúng !";
        } else {
            $_SESSION['username'] = $username;
            $_SESSION['datetime'] = date("d/m/Y H:i:s");
            header("location:index.php");
        }
    }
}
