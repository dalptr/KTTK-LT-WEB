<?php
session_start();
if(!isset($_SESSION['username'])){
    header('location:log_in.php');
}
$conn = new PDO('mysql:host=localhost;dbname=ontap','student','123456');
if(empty($_POST['submit'])){
    $sql = "SELECT * FROM hienthi";
    $stmt = $conn->prepare($sql);
    $query = $stmt->execute();
    $result = array();
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        $result[] = $row;
    }
}
else{
    $timkiem = $_POST['timkiem'];
    $sql = "SELECT * FROM hienthi WHERE hoten LIKE '%$timkiem%'";
    $stmt = $conn->prepare($sql);
    $query = $stmt->execute();
    $result = array();
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        $result[] = $row;
    }
}
